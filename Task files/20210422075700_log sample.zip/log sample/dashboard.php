<?php 
    session_start();
  
    if(!$_SESSION['id']){
        header('location:login1.php');
    }

    
?>
<img src="https://i.makeagif.com/media/4-03-2017/ykFMmH.gif" alt="Girl in a jacket" width="500" height="400">
<h1>Welcome <?php echo ucfirst($_SESSION['first_name']); ?></h1>
<a href="logout.php?logout=true">Logout</a>